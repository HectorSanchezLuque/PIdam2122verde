﻿
namespace ProyectoIntegradoVerde.Formularios
{
    partial class FrmDatos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblNomUser = new System.Windows.Forms.Label();
            this.lblDetalles = new System.Windows.Forms.Label();
            this.lblCode = new System.Windows.Forms.Label();
            this.lblCodigo = new System.Windows.Forms.Label();
            this.lblCargo = new System.Windows.Forms.Label();
            this.lblCargo2 = new System.Windows.Forms.Label();
            this.lblPuntos2 = new System.Windows.Forms.Label();
            this.lblPuntos = new System.Windows.Forms.Label();
            this.lblNif2 = new System.Windows.Forms.Label();
            this.lblNif = new System.Windows.Forms.Label();
            this.ptbFoto = new System.Windows.Forms.PictureBox();
            this.btnCerrar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFoto)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblNombre.Location = new System.Drawing.Point(12, 90);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(117, 29);
            this.lblNombre.TabIndex = 0;
            this.lblNombre.Text = "Nombre ";
            // 
            // lblNomUser
            // 
            this.lblNomUser.AutoSize = true;
            this.lblNomUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblNomUser.Location = new System.Drawing.Point(35, 131);
            this.lblNomUser.Name = "lblNomUser";
            this.lblNomUser.Size = new System.Drawing.Size(41, 18);
            this.lblNomUser.TabIndex = 1;
            this.lblNomUser.Text = "Nom";
            // 
            // lblDetalles
            // 
            this.lblDetalles.AutoSize = true;
            this.lblDetalles.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold);
            this.lblDetalles.Location = new System.Drawing.Point(160, 9);
            this.lblDetalles.Name = "lblDetalles";
            this.lblDetalles.Size = new System.Drawing.Size(343, 39);
            this.lblDetalles.TabIndex = 2;
            this.lblDetalles.Text = "Detalles del Usuario";
            // 
            // lblCode
            // 
            this.lblCode.AutoSize = true;
            this.lblCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblCode.Location = new System.Drawing.Point(12, 184);
            this.lblCode.Name = "lblCode";
            this.lblCode.Size = new System.Drawing.Size(265, 29);
            this.lblCode.TabIndex = 3;
            this.lblCode.Text = "Código de empleado";
            // 
            // lblCodigo
            // 
            this.lblCodigo.AutoSize = true;
            this.lblCodigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblCodigo.Location = new System.Drawing.Point(35, 234);
            this.lblCodigo.Name = "lblCodigo";
            this.lblCodigo.Size = new System.Drawing.Size(44, 18);
            this.lblCodigo.TabIndex = 4;
            this.lblCodigo.Text = "Code";
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblCargo.Location = new System.Drawing.Point(12, 276);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(86, 29);
            this.lblCargo.TabIndex = 6;
            this.lblCargo.Text = "Cargo";
            // 
            // lblCargo2
            // 
            this.lblCargo2.AutoSize = true;
            this.lblCargo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblCargo2.Location = new System.Drawing.Point(35, 327);
            this.lblCargo2.Name = "lblCargo2";
            this.lblCargo2.Size = new System.Drawing.Size(49, 18);
            this.lblCargo2.TabIndex = 7;
            this.lblCargo2.Text = "Cargo";
            // 
            // lblPuntos2
            // 
            this.lblPuntos2.AutoSize = true;
            this.lblPuntos2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblPuntos2.Location = new System.Drawing.Point(35, 420);
            this.lblPuntos2.Name = "lblPuntos2";
            this.lblPuntos2.Size = new System.Drawing.Size(55, 18);
            this.lblPuntos2.TabIndex = 9;
            this.lblPuntos2.Text = "Puntos";
            // 
            // lblPuntos
            // 
            this.lblPuntos.AutoSize = true;
            this.lblPuntos.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblPuntos.Location = new System.Drawing.Point(12, 369);
            this.lblPuntos.Name = "lblPuntos";
            this.lblPuntos.Size = new System.Drawing.Size(98, 29);
            this.lblPuntos.TabIndex = 8;
            this.lblPuntos.Text = "Puntos";
            // 
            // lblNif2
            // 
            this.lblNif2.AutoSize = true;
            this.lblNif2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblNif2.Location = new System.Drawing.Point(35, 515);
            this.lblNif2.Name = "lblNif2";
            this.lblNif2.Size = new System.Drawing.Size(26, 18);
            this.lblNif2.TabIndex = 11;
            this.lblNif2.Text = "Nif";
            // 
            // lblNif
            // 
            this.lblNif.AutoSize = true;
            this.lblNif.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblNif.Location = new System.Drawing.Point(12, 464);
            this.lblNif.Name = "lblNif";
            this.lblNif.Size = new System.Drawing.Size(317, 29);
            this.lblNif.TabIndex = 10;
            this.lblNif.Text = "Número de Identificación";
            // 
            // ptbFoto
            // 
            this.ptbFoto.Location = new System.Drawing.Point(351, 144);
            this.ptbFoto.Name = "ptbFoto";
            this.ptbFoto.Size = new System.Drawing.Size(289, 263);
            this.ptbFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbFoto.TabIndex = 5;
            this.ptbFoto.TabStop = false;
            this.ptbFoto.DoubleClick += new System.EventHandler(this.ptbFoto_DoubleClick);
            // 
            // btnCerrar
            // 
            this.btnCerrar.Location = new System.Drawing.Point(572, 515);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(101, 35);
            this.btnCerrar.TabIndex = 12;
            this.btnCerrar.Text = "Salir";
            this.btnCerrar.UseVisualStyleBackColor = true;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // FrmDatos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(688, 562);
            this.Controls.Add(this.btnCerrar);
            this.Controls.Add(this.lblNif2);
            this.Controls.Add(this.lblNif);
            this.Controls.Add(this.lblPuntos2);
            this.Controls.Add(this.lblPuntos);
            this.Controls.Add(this.lblCargo2);
            this.Controls.Add(this.lblCargo);
            this.Controls.Add(this.ptbFoto);
            this.Controls.Add(this.lblCodigo);
            this.Controls.Add(this.lblCode);
            this.Controls.Add(this.lblDetalles);
            this.Controls.Add(this.lblNomUser);
            this.Controls.Add(this.lblNombre);
            this.Name = "FrmDatos";
            this.Text = "Datos del Usuario";
            this.Load += new System.EventHandler(this.FrmDatos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ptbFoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblNomUser;
        private System.Windows.Forms.Label lblDetalles;
        private System.Windows.Forms.Label lblCode;
        private System.Windows.Forms.Label lblCodigo;
        private System.Windows.Forms.PictureBox ptbFoto;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.Label lblCargo2;
        private System.Windows.Forms.Label lblPuntos2;
        private System.Windows.Forms.Label lblPuntos;
        private System.Windows.Forms.Label lblNif2;
        private System.Windows.Forms.Label lblNif;
        private System.Windows.Forms.Button btnCerrar;
    }
}