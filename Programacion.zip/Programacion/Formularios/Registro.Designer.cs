﻿
namespace ProyectoIntegradoVerde
{
    partial class Registro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dtpFNRegistro = new System.Windows.Forms.DateTimePicker();
            this.lblFNacRegistro = new System.Windows.Forms.Label();
            this.btnVolverRegistro = new System.Windows.Forms.Button();
            this.lblFpRegistro = new System.Windows.Forms.Label();
            this.btnCargarRegistro = new System.Windows.Forms.Button();
            this.pbProfPicRegistro = new System.Windows.Forms.PictureBox();
            this.btnRegistrarseRegistro = new System.Windows.Forms.Button();
            this.txtPasswordRegistro = new System.Windows.Forms.TextBox();
            this.lblPasswordRegistro = new System.Windows.Forms.Label();
            this.txtEmailRegistro = new System.Windows.Forms.TextBox();
            this.lblEmailRegistro = new System.Windows.Forms.Label();
            this.txtCargo = new System.Windows.Forms.TextBox();
            this.lblCargo = new System.Windows.Forms.Label();
            this.txtNombreRegistro = new System.Windows.Forms.TextBox();
            this.lblNombreRegistro = new System.Windows.Forms.Label();
            this.lblRegistro = new System.Windows.Forms.Label();
            this.btnClos = new System.Windows.Forms.Button();
            this.txtNifRegistro = new System.Windows.Forms.TextBox();
            this.lblNifRegistro = new System.Windows.Forms.Label();
            this.chkShowReg = new System.Windows.Forms.CheckBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pbProfPicRegistro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // dtpFNRegistro
            // 
            this.dtpFNRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpFNRegistro.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFNRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFNRegistro.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFNRegistro.Location = new System.Drawing.Point(131, 254);
            this.dtpFNRegistro.Margin = new System.Windows.Forms.Padding(2);
            this.dtpFNRegistro.Name = "dtpFNRegistro";
            this.dtpFNRegistro.Size = new System.Drawing.Size(350, 26);
            this.dtpFNRegistro.TabIndex = 41;
            // 
            // lblFNacRegistro
            // 
            this.lblFNacRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFNacRegistro.AutoSize = true;
            this.lblFNacRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFNacRegistro.ForeColor = System.Drawing.Color.Black;
            this.lblFNacRegistro.Location = new System.Drawing.Point(49, 254);
            this.lblFNacRegistro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFNacRegistro.Name = "lblFNacRegistro";
            this.lblFNacRegistro.Size = new System.Drawing.Size(78, 26);
            this.lblFNacRegistro.TabIndex = 40;
            this.lblFNacRegistro.Text = "Fecha:";
            // 
            // btnVolverRegistro
            // 
            this.btnVolverRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnVolverRegistro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnVolverRegistro.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVolverRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolverRegistro.ForeColor = System.Drawing.Color.White;
            this.btnVolverRegistro.Location = new System.Drawing.Point(649, 552);
            this.btnVolverRegistro.Margin = new System.Windows.Forms.Padding(2);
            this.btnVolverRegistro.Name = "btnVolverRegistro";
            this.btnVolverRegistro.Size = new System.Drawing.Size(88, 32);
            this.btnVolverRegistro.TabIndex = 39;
            this.btnVolverRegistro.Text = "Return";
            this.btnVolverRegistro.UseVisualStyleBackColor = false;
            // 
            // lblFpRegistro
            // 
            this.lblFpRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFpRegistro.AutoSize = true;
            this.lblFpRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFpRegistro.ForeColor = System.Drawing.Color.Black;
            this.lblFpRegistro.Location = new System.Drawing.Point(534, 87);
            this.lblFpRegistro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFpRegistro.Name = "lblFpRegistro";
            this.lblFpRegistro.Size = new System.Drawing.Size(52, 15);
            this.lblFpRegistro.TabIndex = 36;
            this.lblFpRegistro.Text = "Imagen:";
            // 
            // btnCargarRegistro
            // 
            this.btnCargarRegistro.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnCargarRegistro.BackColor = System.Drawing.SystemColors.Control;
            this.btnCargarRegistro.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCargarRegistro.ForeColor = System.Drawing.Color.Black;
            this.btnCargarRegistro.Location = new System.Drawing.Point(675, 302);
            this.btnCargarRegistro.Margin = new System.Windows.Forms.Padding(2);
            this.btnCargarRegistro.Name = "btnCargarRegistro";
            this.btnCargarRegistro.Size = new System.Drawing.Size(56, 23);
            this.btnCargarRegistro.TabIndex = 35;
            this.btnCargarRegistro.Text = "Cargar";
            this.btnCargarRegistro.UseVisualStyleBackColor = false;
            this.btnCargarRegistro.Click += new System.EventHandler(this.btnCargarRegistro_Click);
            // 
            // pbProfPicRegistro
            // 
            this.pbProfPicRegistro.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.pbProfPicRegistro.Location = new System.Drawing.Point(545, 106);
            this.pbProfPicRegistro.Margin = new System.Windows.Forms.Padding(2);
            this.pbProfPicRegistro.Name = "pbProfPicRegistro";
            this.pbProfPicRegistro.Size = new System.Drawing.Size(186, 186);
            this.pbProfPicRegistro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbProfPicRegistro.TabIndex = 34;
            this.pbProfPicRegistro.TabStop = false;
            // 
            // btnRegistrarseRegistro
            // 
            this.btnRegistrarseRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRegistrarseRegistro.BackColor = System.Drawing.SystemColors.Control;
            this.btnRegistrarseRegistro.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRegistrarseRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrarseRegistro.ForeColor = System.Drawing.Color.Black;
            this.btnRegistrarseRegistro.Location = new System.Drawing.Point(131, 419);
            this.btnRegistrarseRegistro.Margin = new System.Windows.Forms.Padding(2);
            this.btnRegistrarseRegistro.Name = "btnRegistrarseRegistro";
            this.btnRegistrarseRegistro.Size = new System.Drawing.Size(350, 40);
            this.btnRegistrarseRegistro.TabIndex = 33;
            this.btnRegistrarseRegistro.Text = "Registrar";
            this.btnRegistrarseRegistro.UseVisualStyleBackColor = false;
            this.btnRegistrarseRegistro.Click += new System.EventHandler(this.btnRegistrarseRegistro_Click);
            // 
            // txtPasswordRegistro
            // 
            this.txtPasswordRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPasswordRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPasswordRegistro.Location = new System.Drawing.Point(131, 346);
            this.txtPasswordRegistro.Margin = new System.Windows.Forms.Padding(2);
            this.txtPasswordRegistro.Name = "txtPasswordRegistro";
            this.txtPasswordRegistro.Size = new System.Drawing.Size(349, 32);
            this.txtPasswordRegistro.TabIndex = 32;
            // 
            // lblPasswordRegistro
            // 
            this.lblPasswordRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPasswordRegistro.AutoSize = true;
            this.lblPasswordRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPasswordRegistro.ForeColor = System.Drawing.Color.Black;
            this.lblPasswordRegistro.Location = new System.Drawing.Point(3, 352);
            this.lblPasswordRegistro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPasswordRegistro.Name = "lblPasswordRegistro";
            this.lblPasswordRegistro.Size = new System.Drawing.Size(74, 26);
            this.lblPasswordRegistro.TabIndex = 31;
            this.lblPasswordRegistro.Text = "Clave:";
            // 
            // txtEmailRegistro
            // 
            this.txtEmailRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEmailRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailRegistro.Location = new System.Drawing.Point(131, 294);
            this.txtEmailRegistro.Margin = new System.Windows.Forms.Padding(2);
            this.txtEmailRegistro.Name = "txtEmailRegistro";
            this.txtEmailRegistro.Size = new System.Drawing.Size(349, 32);
            this.txtEmailRegistro.TabIndex = 30;
            // 
            // lblEmailRegistro
            // 
            this.lblEmailRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEmailRegistro.AutoSize = true;
            this.lblEmailRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailRegistro.ForeColor = System.Drawing.Color.Black;
            this.lblEmailRegistro.Location = new System.Drawing.Point(53, 297);
            this.lblEmailRegistro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEmailRegistro.Name = "lblEmailRegistro";
            this.lblEmailRegistro.Size = new System.Drawing.Size(81, 26);
            this.lblEmailRegistro.TabIndex = 29;
            this.lblEmailRegistro.Text = "E-mail:";
            // 
            // txtCargo
            // 
            this.txtCargo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCargo.Location = new System.Drawing.Point(131, 153);
            this.txtCargo.Margin = new System.Windows.Forms.Padding(2);
            this.txtCargo.Name = "txtCargo";
            this.txtCargo.Size = new System.Drawing.Size(349, 32);
            this.txtCargo.TabIndex = 28;
            // 
            // lblCargo
            // 
            this.lblCargo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCargo.AutoSize = true;
            this.lblCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCargo.ForeColor = System.Drawing.Color.Black;
            this.lblCargo.Location = new System.Drawing.Point(35, 156);
            this.lblCargo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(77, 26);
            this.lblCargo.TabIndex = 27;
            this.lblCargo.Text = "Cargo:";
            // 
            // txtNombreRegistro
            // 
            this.txtNombreRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNombreRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreRegistro.Location = new System.Drawing.Point(131, 103);
            this.txtNombreRegistro.Margin = new System.Windows.Forms.Padding(2);
            this.txtNombreRegistro.Name = "txtNombreRegistro";
            this.txtNombreRegistro.Size = new System.Drawing.Size(349, 32);
            this.txtNombreRegistro.TabIndex = 26;
            // 
            // lblNombreRegistro
            // 
            this.lblNombreRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNombreRegistro.AutoSize = true;
            this.lblNombreRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreRegistro.ForeColor = System.Drawing.Color.Black;
            this.lblNombreRegistro.Location = new System.Drawing.Point(35, 106);
            this.lblNombreRegistro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNombreRegistro.Name = "lblNombreRegistro";
            this.lblNombreRegistro.Size = new System.Drawing.Size(96, 26);
            this.lblNombreRegistro.TabIndex = 25;
            this.lblNombreRegistro.Text = "Nombre:";
            // 
            // lblRegistro
            // 
            this.lblRegistro.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblRegistro.AutoSize = true;
            this.lblRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegistro.ForeColor = System.Drawing.Color.Black;
            this.lblRegistro.Location = new System.Drawing.Point(124, 7);
            this.lblRegistro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRegistro.Name = "lblRegistro";
            this.lblRegistro.Size = new System.Drawing.Size(449, 55);
            this.lblRegistro.TabIndex = 24;
            this.lblRegistro.Text = "Registro de Usuario";
            // 
            // btnClos
            // 
            this.btnClos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClos.BackColor = System.Drawing.SystemColors.Control;
            this.btnClos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClos.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClos.ForeColor = System.Drawing.Color.Black;
            this.btnClos.Location = new System.Drawing.Point(643, 443);
            this.btnClos.Margin = new System.Windows.Forms.Padding(2);
            this.btnClos.Name = "btnClos";
            this.btnClos.Size = new System.Drawing.Size(88, 32);
            this.btnClos.TabIndex = 43;
            this.btnClos.Text = "Cerrar";
            this.btnClos.UseVisualStyleBackColor = false;
            this.btnClos.Click += new System.EventHandler(this.btnClos_Click);
            // 
            // txtNifRegistro
            // 
            this.txtNifRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNifRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNifRegistro.Location = new System.Drawing.Point(133, 201);
            this.txtNifRegistro.Margin = new System.Windows.Forms.Padding(2);
            this.txtNifRegistro.MaxLength = 9;
            this.txtNifRegistro.Name = "txtNifRegistro";
            this.txtNifRegistro.Size = new System.Drawing.Size(349, 32);
            this.txtNifRegistro.TabIndex = 45;
            this.txtNifRegistro.TextChanged += new System.EventHandler(this.txtNifRegistro_TextChanged);
            // 
            // lblNifRegistro
            // 
            this.lblNifRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNifRegistro.AutoSize = true;
            this.lblNifRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNifRegistro.ForeColor = System.Drawing.Color.Black;
            this.lblNifRegistro.Location = new System.Drawing.Point(76, 203);
            this.lblNifRegistro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNifRegistro.Name = "lblNifRegistro";
            this.lblNifRegistro.Size = new System.Drawing.Size(45, 26);
            this.lblNifRegistro.TabIndex = 44;
            this.lblNifRegistro.Text = "Nif:";
            // 
            // chkShowReg
            // 
            this.chkShowReg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkShowReg.AutoSize = true;
            this.chkShowReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowReg.ForeColor = System.Drawing.Color.Black;
            this.chkShowReg.Location = new System.Drawing.Point(131, 382);
            this.chkShowReg.Margin = new System.Windows.Forms.Padding(2);
            this.chkShowReg.Name = "chkShowReg";
            this.chkShowReg.Size = new System.Drawing.Size(150, 21);
            this.chkShowReg.TabIndex = 42;
            this.chkShowReg.Text = "Mostrar contraseña";
            this.chkShowReg.UseVisualStyleBackColor = true;
            this.chkShowReg.CheckedChanged += new System.EventHandler(this.chkShowReg_CheckedChanged);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Registro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 540);
            this.Controls.Add(this.txtNifRegistro);
            this.Controls.Add(this.lblNifRegistro);
            this.Controls.Add(this.btnClos);
            this.Controls.Add(this.chkShowReg);
            this.Controls.Add(this.dtpFNRegistro);
            this.Controls.Add(this.lblFNacRegistro);
            this.Controls.Add(this.btnVolverRegistro);
            this.Controls.Add(this.lblFpRegistro);
            this.Controls.Add(this.btnCargarRegistro);
            this.Controls.Add(this.pbProfPicRegistro);
            this.Controls.Add(this.btnRegistrarseRegistro);
            this.Controls.Add(this.txtPasswordRegistro);
            this.Controls.Add(this.lblPasswordRegistro);
            this.Controls.Add(this.txtEmailRegistro);
            this.Controls.Add(this.lblEmailRegistro);
            this.Controls.Add(this.txtCargo);
            this.Controls.Add(this.lblCargo);
            this.Controls.Add(this.txtNombreRegistro);
            this.Controls.Add(this.lblNombreRegistro);
            this.Controls.Add(this.lblRegistro);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Registro";
            this.Text = "Registro";
            this.Load += new System.EventHandler(this.Registro_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbProfPicRegistro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DateTimePicker dtpFNRegistro;
        private System.Windows.Forms.Label lblFNacRegistro;
        private System.Windows.Forms.Button btnVolverRegistro;
        private System.Windows.Forms.Label lblFpRegistro;
        private System.Windows.Forms.Button btnCargarRegistro;
        private System.Windows.Forms.PictureBox pbProfPicRegistro;
        private System.Windows.Forms.Button btnRegistrarseRegistro;
        private System.Windows.Forms.TextBox txtPasswordRegistro;
        private System.Windows.Forms.Label lblPasswordRegistro;
        private System.Windows.Forms.TextBox txtEmailRegistro;
        private System.Windows.Forms.Label lblEmailRegistro;
        private System.Windows.Forms.TextBox txtCargo;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.TextBox txtNombreRegistro;
        private System.Windows.Forms.Label lblNombreRegistro;
        private System.Windows.Forms.Label lblRegistro;
        private System.Windows.Forms.Button btnClos;
        private System.Windows.Forms.TextBox txtNifRegistro;
        private System.Windows.Forms.Label lblNifRegistro;
        private System.Windows.Forms.CheckBox chkShowReg;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}