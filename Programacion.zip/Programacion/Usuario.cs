﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoIntegradoVerde
{
    internal class Usuario
    {
        private string nif;
        private string nombre;
    }
}
